#! /bin/sh

#
# Make sure mach_kernel.prelink input file is here
#
if [ ! -f mach_kernel.prelink ]
then
	echo =================================================
	echo ==== Error!
	echo ==== You must first copy "mach_kernel.prelink"
	echo ==== into current directory!!
	echo =================================================

	exit 1
fi

#
# ==== decompress original mach_kernel.prelink file
#
echo ========= decompress kernel =========
./prelink_tool -d mach_kernel.prelink mach_kernel_patched.bin
if [ $? -ne 0 ]; then exit 1; fi

#
# ==== patch the decompressed kernel
#
echo ======== patch kernel =========
./poke mach_kernel_patched.bin 0x52055e 0x75:0x75 0x34:0x30
if [ $? -ne 0 ]; then exit 1; fi

./poke mach_kernel_patched.bin 0x52123E 0x75:0x75 0x34:0x30
if [ $? -ne 0 ]; then exit 1; fi

./poke mach_kernel_patched.bin 0x520576 0x75:0x75 0x1c:0x18
if [ $? -ne 0 ]; then exit 1; fi

./poke mach_kernel_patched.bin 0x521256 0x75:0x75 0x1c:0x18
if [ $? -ne 0 ]; then exit 1; fi

#
# ==== compress the patched kernel
#
echo ======= compress kernel =======
./prelink_tool -e mach_kernel_patched.bin mach_kernel_patched.prelink
if [ $? -ne 0 ]; then exit 1; fi
