*****************************************
*		SoftwareMenu Upgrader				*
*****************************************

DISCLAIMER
1. I am in no way responsible for what happens
	It has been extensively tested by me
	but i cannot guarantee anything. If there
	is any problem, please try to reproduce it
	and contact me.

INSTRUCTIONS
1. Read Disclaimer again
2. Select the options you want:
	Option 1: Preserve Files:
		-saves the files after you have updated (except final.dmg)
		-this saves you the download time next time you try to 
		 update
		-If you have the files already downloaded, there is a brief 
		 period where nothing responds. this is because it is 
		 checking the MD5s
	Option 2: Update Immediately:
		-This means that immediately after the downloads have been processed
		 the update will start.
		-This is not recommended but it is up to you to choose
		-There is no way to stop the process once it starts.
	Option 3: Keep Unpatched
		-Not much reason to this but it was easy to add
		-If this is set to yes, you will update to the os you want but
		 it will not be patched (pwn'ed for iphone users).
3. Select the OS you want and go

POSSIBLE ERRORS:
1. Sapphire crashes when you play a movie or show
	remove the metadata at ~/Library/Applications Support/Sapphire/metadata.plist
		