//
//  SMPreviewControlReturns.m
//  SoftwareMenu
//
//  Created by Thomas Cool on 11/5/09.
//  Copyright 2009 Thomas Cool. All rights reserved.
//

#import "SMImageReturns.h"


@implementation SMImageReturns
+(NSArray *)imageProxiesForPath:(NSString *)path
{
    return [SMImageReturns imageProxiesForPath:path nbImages:-1];
}

+(NSArray *)imageProxiesForPath:(NSString *)path nbImages:(long)nb
{
    NSArray *assets = [SMImageReturns mediaAssetsForPath:path];
    NSMutableArray *proxies = [[NSMutableArray alloc] init];
    if (nb<0 || nb>[assets count]) {nb=[assets count];}
    int i;
    id bRXMLImageProxy = NSClassFromString(@"BRXMLImageProxy");
    for (i=0;i<nb;i++)
    {
        [proxies addObject:[bRXMLImageProxy imageProxyForAsset:[assets objectAtIndex:i]]];
    }
    return (NSArray *)proxies;
}

+(NSArray *)mediaAssetsForPath:(NSString *)path
{
    NSArray *coverArtExtention = [[NSArray alloc] initWithObjects:
								  @"jpg",
								  @"JPG",
								  @"jpeg",
								  @"tif",
								  @"tiff",
								  @"png",
								  @"gif",
								  nil];
	NSFileManager *fileManager = [NSFileManager defaultManager];
	long i, count = [[fileManager directoryContentsAtPath:path] count];	
	NSMutableArray *photos =[NSMutableArray arrayWithObjects:nil];
	for ( i = 0; i < count; i++ )
	{
		NSString *idStr = [[fileManager directoryContentsAtPath:path] objectAtIndex:i];
		if([coverArtExtention containsObject:[[idStr pathExtension] lowercaseString]])
		{
			Class cls = NSClassFromString( @"BRPhotoMediaAsset" );
			id asset = [[cls alloc] init];
			[asset setFullURL:[path stringByAppendingPathComponent:idStr]];
			[asset setThumbURL:[path stringByAppendingPathComponent:idStr]];
			[asset setCoverArtURL:[path stringByAppendingPathComponent:idStr]];
			[asset setIsLocal:YES];
			[photos addObject:asset];
           // NSLog(@"path: %@",[path stringByAppendingPathComponent:idStr]);
		}
	}
	return (NSArray *)photos;
}
+(NSArray *)photoCollectionForPath:(NSString *)path
{
    NSArray *assets = [SMImageReturns mediaAssetsForPath:path];
    int i;
    BRPhotoMediaCollection *collection = [BRPhotoMediaCollection collectionWithCollectionInfo:[NSDictionary dictionary]];
    [collection setMediaAssets:assets];
    [collection setCollectionName:@"PhotoCollection"];
    [collection setCollectionType:[BRMediaCollectionType iPhotoFolder]];
    return collection;
}
@end
