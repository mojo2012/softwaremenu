//
//  SMSubclasses.h
//  SoftwareMenu
//
//  Created by Thomas Cool on 11/5/09.
//  Copyright 2009 Thomas Cool. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface SMPhotoBrowserController : BRPhotoBrowserController 
{
    int		padding[16];
}
-(void)removeSButton;

@end

@interface SMPhotoCollectionProvider : BRPhotoDataStoreProvider
-(id)collection;


@end

