//
//  SMSubclasses.m
//  SoftwareMenu
//
//  Created by Thomas Cool on 11/5/09.
//  Copyright 2009 Thomas Cool. All rights reserved.
//

#import "SMSubclasses.h"
#import "SMDefaultPhotos.h"
#import "SMImageReturns.h"
#define PHOTO_DIRECTORY_KEY		@"PhotoDirectory"





@implementation SMPhotoBrowserController
//This is what happens normally when you select an image
/*-(void)_handleSelection:(id)arg1
{
 //Example of how to get image information
    NSLog(@"arg1: %@",arg1);
    NSLog(@"arg1 provider: %@",[arg1 imageProxy]);
    NSLog(@"arg1 provider object: %@",[[arg1 imageProxy] object]);
    NSLog(@"arg1 provider object fullURL: %@",[[[arg1 imageProxy] object] fullURL]);
    //[self _dumpFocusTree];
}*/
//What happens when you press slideshow button
- (void)_handleSlideshowSelection:(id)arg1
{
    NSMutableDictionary *dict = [[ATVSettingsFacade sharedInstance] slideshowScreensaverPlaybackOptions];
    [dict setObject:[NSNumber numberWithInt:10] forKey:@"SecondsPerSlide"];
    id someClass = NSClassFromString(@"BRMediaPlayerController");
    int b;
    id player = [[BRPhotoPlayer alloc ]init ];
    
    [player setPlayerSpecificOptions:dict];
    
    
    [player setMediaAtIndex:0 inCollection:[SMImageReturns photoCollectionForPath:[SMGeneralMethods stringForKey:PHOTO_DIRECTORY_KEY]] error:&b];
    
    id controller_two = [someClass controllerForPlayer:player];
    [[self stack] pushController:controller_two];
}

//Nothing Really
- (void)removeSButton
{
    //[_slideshowButton setText:@"a"];
    //[_slideshowButton removeFromParent];
    //_grid, _slideshow_button, 
    //[self _removeControl:_cursorControl]; //Removes header
    //[self _removeControl:_header]; //removes box around
    //[self _removeControl:_grid]; //Something Missing
    //[self _removeControl:_spinner]; //Something again
    //[self _removeControl:_cursorControl]; //header again
    //[self _removeControl:_scroller];  //grid again
    //[self _removeControl:_bannerControl];
    [self _removeControl:_noContentMessageControl];
    //[self _removeControl:_slideshowButton]; // removes grid
}
@end
@implementation SMPhotoCollectionProvider
//Adding something to return a collection
-(id)collection
{
    BRPhotoMediaCollection *collection = [BRPhotoMediaCollection collectionWithCollectionInfo:[NSDictionary dictionary]];
    [collection setMediaAssets:[[self dataStore] data]];
    [collection setCollectionName:@"PhotoCollection"];
    [collection setCollectionType:[BRMediaCollectionType iPhotoFolder]];
    return collection;
}

@end
